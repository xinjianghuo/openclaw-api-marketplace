# Node Connection Doctor

**诊断和修复 OpenClaw 节点连接问题**

## 📋 概述

这个技能帮助用户快速诊断和解决 OpenClaw 节点连接故障。覆盖常见场景：
- QR/setup code 扫描失败
- 手动连接失败 (unauthorized, bootstrap token invalid)
- Tailscale/VPN 问题
- gateway.bind / gateway.remote.url 配置错误

## 🎯 核心功能

1. **自动诊断流程**
   - 检查网关状态 (`openclaw gateway status`)
   - 验证节点配对配置 (`plugins.entries.device-pair.config`)
   - 测试网络连通性 (ping, Tailscale status)

2. **生成修复建议**
   - 根据错误代码提供具体解决方案
   - 提供 CLI 命令示例
   - 导出诊断报告

3. **一键修复 (可选)**
   - 自动重置配对 token
   - 重新绑定网关
   - 重启网关服务

## 🔧 使用示例

```yaml
# 诊断节点连接问题
skill: node-connection-doctor
input:
  mode: diagnose
  verbose: true
```

```yaml
# 一键修复 (需要确认)
skill: node-connection-doctor
input:
  mode: fix
  auto_confirm: false
```

## 💰 定价

- **单次诊断**: $5
- **完整修复服务**: $15
- **企业版 (API)**: $50/月

## 📊 预期价值

- 节省时间: 30 分钟 → 2 分钟
- 减少错误: 自动识别 20+ 常见问题
- 提高成功率: 95% 问题可自动修复

## 🛠️ 技术要求

基于 `node-connect` skill 核心逻辑，简化用户界面，增强错误分类。

---

*Skill ID: node-connection-doctor*  
*Category: Troubleshooting*  
*Maintenance: Active*  
*Compatible: OpenClaw v2026.3.23+*
